require('ts-node/register');
require('./src/main');