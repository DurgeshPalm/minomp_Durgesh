// import { PartialType } from '@nestjs/swagger';
// import { CreateAuthanticationDto } from './create-authantication.dto';

// export class UpdateAuthanticationDto extends PartialType(CreateAuthanticationDto) {}
