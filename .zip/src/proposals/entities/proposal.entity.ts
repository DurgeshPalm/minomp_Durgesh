export class Proposal {}
