export class CreateErrorLogDto {}
