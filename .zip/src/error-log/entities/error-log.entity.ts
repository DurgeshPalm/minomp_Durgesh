export class ErrorLog {}
